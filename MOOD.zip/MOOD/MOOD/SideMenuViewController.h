//
//  SideMenuViewController.h
//  MFSideMenuDemo
//
//  Created by Michael Frederick on 3/19/12.

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface SideMenuViewController : UITableViewController
{
     AppDelegate* _appDelegate;
}

@end