//
//  LocatioDetailVC.h
//  DatingAp
//
//  Created by Mac on 20/02/14.
//  Copyright (c) 2014 Antier Solutions pvt ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MFSideMenu.h"
#import "MFSideMenuContainerViewController.h"
#import "AppDelegate.h"

@interface LocatioDetailVC : UIViewController
{
    AppDelegate* _appDelegate;
}

@end
