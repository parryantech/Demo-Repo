//
//  RedeemVC.h
//  DatingAp
//
//  Created by Mac on 20/02/14.
//  Copyright (c) 2014 Antier Solutions pvt ltd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface RedeemVC : UIViewController<UISearchBarDelegate,UISearchDisplayDelegate>
{
    IBOutlet UISearchBar *saerchBar;
    AppDelegate* _appDelegate;
    NSMutableArray *ListArr;
    IBOutlet UITableView *ListTable;
    IBOutlet UIScrollView *listScroll;
    UIImageView *mageView;
}

@end
