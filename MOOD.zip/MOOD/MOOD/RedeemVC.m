//
//  RedeemVC.m
//  DatingAp
//
//  Created by Mac on 20/02/14.
//  Copyright (c) 2014 Antier Solutions pvt ltd. All rights reserved.
//

#import "RedeemVC.h"
#import "MFSideMenu.h"
#import "ViewController.h"

@interface RedeemVC ()

@end

@implementation RedeemVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    ListArr=[[NSMutableArray alloc] initWithObjects:@"Alternative",@"Blues",@"Classical",@"Country",@"Dance",@"Electronic", nil];
    [super viewDidLoad];
    [listScroll setContentSize:CGSizeMake(960, 0)];
    _appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    [self setupMenuBarButtonItems];
    self.menuContainerViewController.panMode = MFSideMenuPanModeNone;
    mageView = [[UIImageView alloc]init];
    mageView.frame = CGRectMake(235, 5, 35, 35);
    mageView.contentMode = UIViewContentModeScaleAspectFit;
    mageView.image = [UIImage imageNamed:@"point.png"];
    mageView.clipsToBounds = YES;
    mageView.tag=99;
    
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:235.0f/255.0f green:34.0f/255.0f blue:35.0f/255.0f alpha:1.0];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor blackColor]}];
    
    [self.navigationController.navigationBar addSubview:mageView];
    self.title=@"Rewards Store";
    // Do any additional setup after loading the view from its nib.
}

#pragma mark -
#pragma mark - UIBarButtonItems

- (void)setupMenuBarButtonItems
{
    self.navigationItem.rightBarButtonItem = [self rightMenuBarButtonItem];
    self.navigationItem.leftBarButtonItem = [self leftMenuBarButtonItem];

}

- (UIBarButtonItem *)leftMenuBarButtonItem
{
    return [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back_arrow.png"] style:UIBarButtonItemStyleBordered   target:self action:@selector(leftSideMenuButtonPressed:)];
}

- (UIBarButtonItem *)rightMenuBarButtonItem
{
    return [[UIBarButtonItem alloc]
            initWithImage:[UIImage imageNamed:@"homefinal.png"] style:UIBarButtonItemStyleBordered
            target:self
            action:@selector(rightSideMenuButtonPressed:)];
}

- (UIBarButtonItem *)backBarButtonItem
{
    return [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"back_arrow"]
                                            style:UIBarButtonItemStyleBordered
                                           target:self
                                           action:@selector(backButtonPressed:)];
}


#pragma mark -
#pragma mark - UIBarButtonItem Callbacks

- (void)leftSideMenuButtonPressed:(id)sender
{
    UIView *removeView;
    while((removeView = [self.navigationController.navigationBar viewWithTag:99]) != nil)
    {
        [removeView removeFromSuperview];
    }
    _appDelegate.redeemCoupon=@"yes";
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)rightSideMenuButtonPressed:(id)sender
{
    UIView *removeView;
    while((removeView = [self.navigationController.navigationBar viewWithTag:99]) != nil)
    {
        [removeView removeFromSuperview];
    }
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark -
#pragma mark - UIBarButtonItem Callbacks

- (void)backButtonPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (NSInteger) tableView:(UITableView*) tableView numberOfRowsInSection:(NSInteger) section
{
	return 6;
}

- (UITableViewCell*) tableView:(UITableView*) tableView cellForRowAtIndexPath:(NSIndexPath*) indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PeerCell"];
	if (!cell)
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"PeerCell"];
	   cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.textLabel.text=[NSString stringWithFormat:@"%@",[ListArr objectAtIndex:indexPath.row]];
    
	return cell;
}

- (void) tableView:(UITableView*) tableView didSelectRowAtIndexPath:(NSIndexPath*) indexPath
{
//    UIView *removeView;
//    while((removeView = [self.navigationController.navigationBar viewWithTag:99]) != nil)
//    {
//        [removeView removeFromSuperview];
//    }
//    [self.navigationController popViewControllerAnimated:NO];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar1;
{
    [saerchBar resignFirstResponder];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
