//
//  MoodPresence.h
//  MoodPresence
//
//  Copyright (c) 2013 Mood Media. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum _message_type {
    MM_MOOD_PRESENCE_RESULT_TYPE_SONIC = 0,
    MM_MOOD_PRESENCE_RESULT_TYPE_ULTRASONIC
} MMMoodPresenceResultType;


@interface MMMoodPresenceResult : NSObject

@property (readonly, nonatomic, assign) MMMoodPresenceResultType type;
@property (readonly, nonatomic, assign) NSInteger presenceId;

@end


@protocol MMMoodPresenceDelegate <NSObject>

@optional
- (BOOL) didDetectPresenceCode:(MMMoodPresenceResult *)result;
- (void) didRecieveInterstitialData:(NSData *)data;
- (void) didRecieveLocationData:(NSData *)data;

@end


@interface MoodPresence : NSObject

@property (nonatomic, weak) id delegate;
@property (nonatomic, strong) NSString *sdkKey;

+ (id) sharedMoodPresence;
+ (id) sharedMoodPresenceWithSdkKey:(NSString*)key;
+ (id) sharedMoodPresenceWithSdkKey:(NSString*)key usesMicrophone:(BOOL)microphone;


- (id) initWithSdkKey:(NSString*)key;

- (void) startListening;
- (void) stopListening;

- (void) userDidTapBannerID:(NSUInteger)bannerID;

- (void) startMonitoringRegionCrossings;
- (void) stopMonitoringRegionCrossings;

- (void)endAllRegionMonitoringBackgroundTasks;

- (void)produce:(const void *)inData frameCount:(NSUInteger)inFrameCount;
- (void)reset;

@end
