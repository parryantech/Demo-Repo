//
//  ViewController.h
//  MOOD
//
//  Created by admin on 20/02/14.
//  Copyright (c) 2014 Antech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MoodPresence.h"
#import <QuartzCore/QuartzCore.h>
#import "AppDelegate.h"
#import <math.h>
#define DegreesToRadians(x) (M_PI * x / 180.0)
@interface ViewController : UIViewController<MMMoodPresenceDelegate,UITableViewDataSource,UITableViewDelegate>
{
    IBOutlet UIView *sharingSubView;
    BOOL flipped;
    NSMutableArray *TitleArr;
    AppDelegate* _appDelegate;
    IBOutlet UITableView *LocationTable;
    IBOutlet UILabel *couponDescritpionLbl;
    IBOutlet UIView *couponView;
    IBOutlet UIImageView *searchImageView;
    NSString *couponVal;
    NSMutableArray *subtitleArr;
    IBOutlet UIButton *BGbutton;
    IBOutlet UIView *blurOverView;
}
- (IBAction)BtnClick:(id)sender;
- (IBAction)sharingBtn:(id)sender;
- (IBAction)sharedBtnClicked:(id)sender;

@property (strong,nonatomic) MoodPresence *moodPresence;
@end
