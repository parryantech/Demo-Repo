//
//  SideMenuViewController.m
//  MFSideMenuDemo
//
//  Created by Michael Frederick on 3/19/12.

#import "SideMenuViewController.h"
#import "MFSideMenu.h"
#import "ViewController.h"
#import "RedeemVC.h"
@implementation SideMenuViewController

#pragma mark -
#pragma mark - UITableViewDataSource

- (void)viewDidLoad
{
    _appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    self.tableView.separatorInset=UIEdgeInsetsZero;
    self.tableView.scrollEnabled=NO;
    [super viewDidLoad];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (IS_IPHONE5)
        return 569;
    else
        return 481;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
//        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    
//    cell.imageView.image=[UIImage imageNamed:@"BGpanal.png"];
    UIImageView *imageBg=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0,226, 482)];
    imageBg.image=[UIImage imageNamed:@"BGpanal.png"];
    [cell.contentView addSubview:imageBg];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self
               action:@selector(aMethod:)
     forControlEvents:UIControlEventTouchDown];
    [button setTitle:@"" forState:UIControlStateNormal];
    button.frame = CGRectMake(20, 340.0, 190, 50.0);
    
    if (IS_IPHONE5)
    {
        button.frame = CGRectMake(20, 400.0, 190, 50.0);
        imageBg.frame = CGRectMake(0, 0,226, 568);
    }
  
    [cell.contentView addSubview:button];
    return cell;
}
-(void)aMethod:(id)sender
{
    _appDelegate.redeemCoupon=@"yes";
    _appDelegate.pushStr=@"yes";
    ViewController *demoController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
    demoController.title = [NSString stringWithFormat:@"Rewards Store"];
    [self.menuContainerViewController setMenuState:MFSideMenuStateClosed];
    UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
    NSArray *controllers = [NSArray arrayWithObject:demoController];
    navigationController.viewControllers = controllers;
}

#pragma mark -
#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
//    ViewController *demoController = [[ViewController alloc] initWithNibName:@"ViewController" bundle:nil];
//    demoController.title = [NSString stringWithFormat:@"Demo #%d-%d", indexPath.section, indexPath.row];
//    
//    UINavigationController *navigationController = self.menuContainerViewController.centerViewController;
//    NSArray *controllers = [NSArray arrayWithObject:demoController];
//    navigationController.viewControllers = controllers;
//    [self.menuContainerViewController setMenuState:MFSideMenuStateClosed];
}

@end
