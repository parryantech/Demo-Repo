//
//  AppDelegate.h
//  MOOD
//
//  Created by admin on 20/02/14.
//  Copyright (c) 2014 Antech. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    UINavigationController *navcon;
}
@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) ViewController *viewController;
@property (strong, nonatomic) NSString *redeemCoupon,*pushStr;

@end
