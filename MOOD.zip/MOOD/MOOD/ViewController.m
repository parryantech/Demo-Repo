//
//  ViewController.m
//  MOOD
//
//  Created by admin on 20/02/14.
//  Copyright (c) 2014 Antech. All rights reserved.
//

#import "ViewController.h"
#import "MFSideMenu.h"
#import "SideMenuViewController.h"
#import "RedeemVC.h"
#import "MFSideMenuContainerViewController.h"
#import "LocatioDetailVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [[NSNotificationCenter defaultCenter] addObserver: self selector: @selector(enteredBackground:)  name: @"didEnterBackground"  object: nil];
    [self setupMenuBarButtonItems];
    _appDelegate = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    self.moodPresence = [MoodPresence sharedMoodPresence];
    [self.moodPresence setSdkKey:@"476bff51a91d416b8cdb2e89db4c129f"];
    [self.moodPresence setDelegate:self];
    
    if (IS_IPHONE5)
    {
        searchImageView.frame=CGRectMake(0, 0, 320, 568);
        searchImageView.image=[UIImage imageNamed:@"search_iphn5.png"];
    }
    else
    {
        searchImageView.frame=CGRectMake(0, 0, 320, 480);
        searchImageView.image=[UIImage imageNamed:@"search_iphn4.png"];
    }
    
    sharingSubView.hidden=YES;
    self.title=[NSString stringWithFormat:@"Nearby Locations"];
    self.menuContainerViewController.panMode = MFSideMenuPanModeNone;
	// Do any additional setup after loading the view, typically from a nib.
    
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:235.0f/255.0f green:34.0f/255.0f blue:35.0f/255.0f alpha:1.0];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor blackColor]}];
    
    [self.navigationController setNavigationBarHidden:YES];
    
    TitleArr=[[NSMutableArray alloc] initWithObjects:@"Clothing Store",@"Urban Style",@"The Home Store",@"El Taco Mucho",@"Hardware Warehouse",@"Toy Bin",@"Dress Express",@"Joe's Bar anf Grille",@"Fashion World",@"Crafts Plus",@"Quick Sale Mart", nil];
    
    subtitleArr=[[NSMutableArray alloc] initWithObjects:@"0.07 ml.",@"0.89 ml.",@"4.24 ml.",@"6.03 ml.",@"6.97 ml.",@"6.97 ml.",@"7.55 ml.",@"8.15 ml.",@"8.46 ml.",@"9.06 ml.",@"9.98 ml.", nil];
    
    if ([_appDelegate.redeemCoupon isEqualToString:@"yes"])
    {
        [self.navigationController setNavigationBarHidden:NO];
        BGbutton.hidden=YES;
        blurOverView.hidden=YES;
        [searchImageView setHidden:YES];
        [couponView setHidden:YES];
        [self.moodPresence stopListening];
        _appDelegate.redeemCoupon=@"no";
    }
    else
    {
        BGbutton.hidden=NO;
        blurOverView.hidden=NO;
        [searchImageView setHidden:NO];
        [couponView setHidden:YES];
        [self.moodPresence startListening];
    }
    
    NSString *str= [NSString stringWithFormat:@"%@",_appDelegate.pushStr];
    if ([str isEqualToString:@"yes"])
    {
        RedeemVC *demoController = [[RedeemVC alloc] initWithNibName:@"RedeemVC" bundle:nil];
        [self.navigationController pushViewController:demoController animated:YES];
        _appDelegate.pushStr=@"no";
        return;
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    flipped = NO;
    if (IS_IPHONE5)
    {
        searchImageView.frame=CGRectMake(0, 0, 320, 568);
        searchImageView.image=[UIImage imageNamed:@"search_iphn5.png"];
    }
    else
    {
        searchImageView.frame=CGRectMake(0, 0, 320, 480);
        searchImageView.image=[UIImage imageNamed:@"search_iphn4.png"];
    }

    [super viewDidAppear:animated];
    // Begin listening for audio watermarks
    if ([_appDelegate.redeemCoupon isEqualToString:@"yes"])
    {
        self.menuContainerViewController.panMode = MFSideMenuPanModeDefault;
        [self.navigationController setNavigationBarHidden:NO];
        BGbutton.hidden=YES;
        blurOverView.hidden=YES;
        [searchImageView setHidden:YES];
        [couponView setHidden:YES];
        [self.moodPresence stopListening];
        _appDelegate.redeemCoupon=@"no";
    }
    else
    {
        self.menuContainerViewController.panMode = MFSideMenuPanModeNone;
        [self.navigationController setNavigationBarHidden:YES];
        BGbutton.hidden=NO;
        blurOverView.hidden=NO;
        [searchImageView setHidden:NO];
        [couponView setHidden:YES];
        [self.moodPresence startListening];
    }
}

-(void)enteredBackground:(NSNotification *) notification
{
    [self.menuContainerViewController setMenuState:MFSideMenuStateClosed];
    [self.navigationController setNavigationBarHidden:YES];
    sharingSubView.hidden=YES;
    [searchImageView setHidden:NO];
    [couponView setHidden:YES];
    BGbutton.hidden=NO;
    blurOverView.hidden=NO;
    [self.moodPresence stopListening];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL) didDetectPresenceCode:(MMMoodPresenceResult *)result;
{
    dispatch_async(dispatch_get_main_queue(), ^{
       
        // The presenceId property is the numeric identifier for the watermark
        NSInteger message = [result presenceId];
        
        NSLog(@"Heard message: %d", (int)message);
        
        UIView *circleView = [[UIView alloc] initWithFrame:CGRectMake(90,20,80,80)];
        circleView.alpha = 0.8;
        circleView.layer.cornerRadius = 40;
        circleView.backgroundColor = [UIColor redColor];
        
        UILabel *label=[[UILabel alloc] init];
        label.frame=CGRectMake(2, 0, 80, 80);
        label.textAlignment=NSTextAlignmentCenter;
        [label setFont:[UIFont boldSystemFontOfSize:32]];
        label.text=[NSString stringWithFormat:@"+%d",(int)message];
        
        [circleView addSubview:label];
        
        // setup the animation group and creates it
        [UIView beginAnimations:nil context:nil];
        [UIView setAnimationDuration:0.75];
        [UIView setAnimationDelegate:self];
        
        // If view one is visible, hides it and add the new one with the "Flip" style transition
        [UIView setAnimationTransition:UIViewAnimationTransitionFlipFromRight forView:self.view cache:YES];
        [searchImageView setHidden:YES];
        [couponView setHidden:NO];
        
        // Commit animations to show the effect
        [UIView commitAnimations];
        
        [couponView addSubview:circleView];
        couponView.layer.cornerRadius=10;
        couponDescritpionLbl.text=[NSString stringWithFormat:@"You have earned %d points for visiting this retail store", (int)message];
    });
    
    [self.moodPresence stopListening];
    return NO;
}

#pragma mark -
#pragma mark - UIBarButtonItems

- (void)setupMenuBarButtonItems
{
    self.navigationItem.rightBarButtonItem = [self rightMenuBarButtonItem];
    self.navigationItem.leftBarButtonItem = [self leftMenuBarButtonItem];

}

- (UIBarButtonItem *)leftMenuBarButtonItem
{
    return [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"menu-icon.png"] style:UIBarButtonItemStyleBordered target:self action:@selector(leftSideMenuButtonPressed:)];
}

- (UIBarButtonItem *)rightMenuBarButtonItem
{
    return [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"homefinal.png"] style:UIBarButtonItemStyleBordered  target:self  action:@selector(rightSideMenuButtonPressed:)];
}

- (UIBarButtonItem *)backBarButtonItem
{
    return [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"menu-icon.png"] style:UIBarButtonItemStyleBordered target:self  action:@selector(backButtonPressed:)];
}


#pragma mark -
#pragma mark - UIBarButtonItem Callbacks

- (void)backButtonPressed:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}

- (void)leftSideMenuButtonPressed:(id)sender
{
    [self.menuContainerViewController toggleLeftSideMenuCompletion:^{
        [self setupMenuBarButtonItems];
    }];
}

- (void)rightSideMenuButtonPressed:(id)sender
{
    self.menuContainerViewController.panMode = MFSideMenuPanModeNone;
    [self.navigationController setNavigationBarHidden:YES];
    [searchImageView setHidden:NO];
    [couponView setHidden:YES];
    BGbutton.hidden=NO;
    blurOverView.hidden=NO;
    [self.moodPresence startListening];
}

- (NSInteger) tableView:(UITableView*) tableView numberOfRowsInSection:(NSInteger) section
{
	return 11;
}

- (UITableViewCell*) tableView:(UITableView*) tableView cellForRowAtIndexPath:(NSIndexPath*) indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PeerCell"];
	if (!cell)
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"PeerCell"];
	
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    cell.textLabel.text=[NSString stringWithFormat:@"%@",[TitleArr objectAtIndex:indexPath.row]];
    
    UILabel *distLbl=[[UILabel alloc] initWithFrame:CGRectMake(250, 15, 80, 15)];
    [distLbl setTextColor:[UIColor lightGrayColor]];
    [distLbl setFont:[UIFont systemFontOfSize:9.0]];
    distLbl.text=[subtitleArr objectAtIndex:indexPath.row];
    [cell.contentView addSubview:distLbl];
    	return cell;
}

- (void) tableView:(UITableView*) tableView didSelectRowAtIndexPath:(NSIndexPath*) indexPath
{
//        if (indexPath.row==0)
//        {
            LocatioDetailVC *demoController = [[LocatioDetailVC alloc] initWithNibName:@"LocatioDetailVC" bundle:nil];
            [self.navigationController pushViewController:demoController animated:YES];
//        }
//        else
//        {
//            self.menuContainerViewController.panMode = MFSideMenuPanModeNone;
//            [self.navigationController setNavigationBarHidden:YES];
//            [searchImageView setHidden:NO];
//            [couponView setHidden:YES];
//            BGbutton.hidden=NO;
//            blurOverView.hidden=NO;
//            [self.moodPresence startListening];
//        }
}

- (IBAction)BtnClick:(id)sender
{
    [self.navigationController setNavigationBarHidden:NO];
    BGbutton.hidden=YES;
    blurOverView.hidden=YES;
    self.menuContainerViewController.panMode = MFSideMenuPanModeDefault;
    [couponView setHidden:YES];
}

- (IBAction)sharingBtn:(id)sender
{
    sharingSubView.hidden=NO;
    [UIView animateWithDuration:0.8 animations:^(void)
     {
         sharingSubView.frame=CGRectMake(0, 0, 320, 568);
         sharingSubView.alpha = 1.0;
     }];
}

-(void)hideAgain
{
    [UIView animateWithDuration:0 animations:^(void)
     {
         sharingSubView.frame=CGRectMake(0, 568, 320, 568);
         sharingSubView.alpha = 1.0;
     }];
}

- (IBAction)sharedBtnClicked:(id)sender
{
    [self.navigationController setNavigationBarHidden:NO];
    BGbutton.hidden=YES;
    blurOverView.hidden=YES;
    self.menuContainerViewController.panMode = MFSideMenuPanModeDefault;
    [couponView setHidden:YES];
    [UIView animateWithDuration:0.7 animations:^{sharingSubView.alpha = 0.0;}];
    
    [self performSelector:@selector(hideAgain) withObject:nil afterDelay:1.0];

}
@end
